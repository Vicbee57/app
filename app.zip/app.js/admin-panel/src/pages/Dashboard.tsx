import React from 'react';
import ResultChecker from '../components/ResultChecker';

const Dashboard: React.FC = () => {
    return (
        <div>
            <h1>Admin Dashboard</h1>
            <ResultChecker />
        </div>
    );
};

export default Dashboard;