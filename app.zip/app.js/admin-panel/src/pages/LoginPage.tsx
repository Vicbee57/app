import React from 'react';
import Login from '../components/Login';

const LoginPage: React.FC = () => {
    return (
        <div>
            <h1>XXX CODES Admin Panel Login</h1>
            <Login />
        </div>
    );
};

export default LoginPage;