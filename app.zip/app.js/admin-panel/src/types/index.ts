export interface UserCredentials {
    username: string;
    password: string;
}

export interface ResultData {
    subject: string;
    score: number;
    grade: string;
}